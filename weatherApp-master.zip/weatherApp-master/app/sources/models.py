from enum import Enum


class Models(Enum):
    icon_d2 = "rapid-id2"
    icon_eu = "icon-eu"
    icon_global = "icon-world"
    ecmwf = "euro"
    gfs = "usa"

